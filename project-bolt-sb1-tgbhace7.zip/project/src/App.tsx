import React, { useState, useEffect } from 'react';
import { User, Avatar } from './types';
import { storage } from './utils/storage';

// Components
import { Layout } from './components/Layout';
import { AuthScreen } from './components/AuthScreen';
import { AvatarQuiz } from './components/AvatarQuiz';
import { AvatarReveal } from './components/AvatarReveal';
import { Dashboard } from './components/Dashboard';
import { ChatScreen } from './components/ChatScreen';
import { SleepTracker } from './components/SleepTracker';
import { DailyQuiz } from './components/DailyQuiz';
import { ProgressScreen } from './components/ProgressScreen';
import { Settings } from './components/Settings';

type AppState = 'auth' | 'quiz' | 'reveal' | 'main';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [appState, setAppState] = useState<AppState>('auth');
  const [currentView, setCurrentView] = useState('dashboard');
  const [language, setLanguage] = useState<'en' | 'rus'>('en');
  const [selectedAvatar, setSelectedAvatar] = useState<Avatar | null>(null);

  useEffect(() => {
    // Load user from storage
    const savedUser = storage.getUser();
    if (savedUser) {
      setUser(savedUser);
      setLanguage(savedUser.settings.language);
      if (savedUser.avatar) {
        setAppState('main');
      } else {
        setAppState('quiz');
      }
    }
  }, []);

  const handleAuth = (newUser: User) => {
    setUser(newUser);
    storage.setUser(newUser);
    setLanguage(newUser.settings.language);
    setAppState('quiz');
  };

  const handleQuizComplete = (updatedUser: User, avatar: Avatar) => {
    setUser(updatedUser);
    setSelectedAvatar(avatar);
    storage.setUser(updatedUser);
    setAppState('reveal');
  };

  const handleRevealContinue = () => {
    setAppState('main');
    setCurrentView('dashboard');
  };

  const handleUserUpdate = (updatedUser: User) => {
    setUser(updatedUser);
    setLanguage(updatedUser.settings.language);
    storage.setUser(updatedUser);
  };

  const handleLogout = () => {
    setUser(null);
    setAppState('auth');
    setCurrentView('dashboard');
    storage.clearAll();
  };

  const handleDailyQuizComplete = (updatedUser: User) => {
    setUser(updatedUser);
    setCurrentView('dashboard');
  };

  if (appState === 'auth') {
    return (
      <AuthScreen 
        onAuth={handleAuth}
        language={language}
        onLanguageChange={setLanguage}
      />
    );
  }

  if (appState === 'quiz' && user) {
    return (
      <AvatarQuiz 
        user={user}
        onComplete={handleQuizComplete}
      />
    );
  }

  if (appState === 'reveal' && user && selectedAvatar) {
    return (
      <AvatarReveal 
        user={user}
        avatar={selectedAvatar}
        onContinue={handleRevealContinue}
      />
    );
  }

  if (appState === 'main' && user) {
    return (
      <Layout 
        user={user}
        currentView={currentView}
        onViewChange={setCurrentView}
      >
        {currentView === 'dashboard' && (
          <Dashboard 
            user={user}
            onViewChange={setCurrentView}
          />
        )}
        {currentView === 'chat' && (
          <ChatScreen user={user} />
        )}
        {currentView === 'sleep' && (
          <SleepTracker user={user} />
        )}
        {currentView === 'quiz' && (
          <DailyQuiz 
            user={user}
            onComplete={handleDailyQuizComplete}
          />
        )}
        {currentView === 'progress' && (
          <ProgressScreen user={user} />
        )}
        {currentView === 'settings' && (
          <Settings 
            user={user}
            onUserUpdate={handleUserUpdate}
            onLogout={handleLogout}
          />
        )}
      </Layout>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center">
      <div className="animate-spin w-8 h-8 border-4 border-purple-200 border-t-purple-500 rounded-full"></div>
    </div>
  );
}

export default App;