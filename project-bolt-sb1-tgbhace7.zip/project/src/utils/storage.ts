import { User, DailyQuiz, Challenge, ChatMessage, SleepData } from '../types';

const STORAGE_KEYS = {
  USER: 'factum_user',
  DAILY_QUIZZES: 'factum_daily_quizzes',
  CHALLENGES: 'factum_challenges',
  CHAT_MESSAGES: 'factum_chat_messages',
  SLEEP_DATA: 'factum_sleep_data',
} as const;

export const storage = {
  // User data
  getUser: (): User | null => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    return data ? JSON.parse(data) : null;
  },

  setUser: (user: User): void => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },

  // Daily quizzes
  getDailyQuizzes: (): DailyQuiz[] => {
    const data = localStorage.getItem(STORAGE_KEYS.DAILY_QUIZZES);
    return data ? JSON.parse(data) : [];
  },

  addDailyQuiz: (quiz: DailyQuiz): void => {
    const quizzes = storage.getDailyQuizzes();
    quizzes.push(quiz);
    localStorage.setItem(STORAGE_KEYS.DAILY_QUIZZES, JSON.stringify(quizzes));
  },

  // Challenges
  getChallenges: (): Challenge[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHALLENGES);
    return data ? JSON.parse(data) : [];
  },

  setChallenges: (challenges: Challenge[]): void => {
    localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(challenges));
  },

  // Chat messages
  getChatMessages: (): ChatMessage[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHAT_MESSAGES);
    return data ? JSON.parse(data) : [];
  },

  addChatMessage: (message: ChatMessage): void => {
    const messages = storage.getChatMessages();
    messages.push(message);
    localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(messages));
  },

  // Sleep data
  getSleepData: (): SleepData | null => {
    const data = localStorage.getItem(STORAGE_KEYS.SLEEP_DATA);
    return data ? JSON.parse(data) : null;
  },

  setSleepData: (sleepData: SleepData): void => {
    localStorage.setItem(STORAGE_KEYS.SLEEP_DATA, JSON.stringify(sleepData));
  },

  // Clear all data
  clearAll: (): void => {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  }
};