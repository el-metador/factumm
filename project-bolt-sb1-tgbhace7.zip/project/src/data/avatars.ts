import { Avatar } from '../types';

export const avatars: Avatar[] = [
  {
    id: 'luna',
    name: 'Luna',
    type: 'Luna',
    description: 'Gentle companion for night anxiety and emotional sensitivity',
    color: 'from-purple-400 to-indigo-600',
    icon: '🌙',
    traits: ['night anxiety', 'emotional sensitivity', 'overthinking', 'sleep issues']
  },
  {
    id: 'sunny',
    name: 'Sunny',
    type: 'Sunny',
    description: 'Warm guide through light depression and low motivation',
    color: 'from-yellow-400 to-orange-500',
    icon: '☀️',
    traits: ['light depression', 'apathy', 'low motivation', 'seasonal sadness']
  },
  {
    id: 'sage',
    name: 'Sage',
    type: 'Sage',
    description: 'Wise mentor for self-esteem and social confidence',
    color: 'from-green-400 to-teal-600',
    icon: '🌿',
    traits: ['low self-esteem', 'chronic self-doubt', 'social anxiety', 'imposter syndrome']
  },
  {
    id: 'spark',
    name: 'Spark',
    type: 'Spark',
    description: 'Energetic coach for motivation and focus',
    color: 'from-red-400 to-pink-600',
    icon: '⚡',
    traits: ['apathy', 'procrastination', 'executive dysfunction', 'lack of focus']
  },
  {
    id: 'haven',
    name: 'Haven',
    type: 'Haven',
    description: 'Safe space for trauma recovery and social healing',
    color: 'from-blue-400 to-cyan-600',
    icon: '🏠',
    traits: ['social anxiety', 'attachment issues', 'trauma', 'burnout']
  }
];