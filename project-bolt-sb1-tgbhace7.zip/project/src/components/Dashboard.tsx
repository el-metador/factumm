import React from 'react';
import { User, Challenge } from '../types';

interface DashboardProps {
  user: User;
  onViewChange: (view: string) => void;
}

export function Dashboard({ user, onViewChange }: DashboardProps) {
  const language = user.settings.language;
  const avatar = user.avatar;

  const text = {
    en: {
      goodMorning: 'Good morning',
      goodAfternoon: 'Good afternoon', 
      goodEvening: 'Good evening',
      todaysGoals: "Today's Goals",
      checkIn: 'Daily Check-in',
      checkInDesc: 'How are you feeling today?',
      sleepTracker: 'Sleep Tracker',
      sleepDesc: 'Optimize your rest cycles',
      chatWithAvatar: `Chat with ${avatar?.name}`,
      chatDesc: 'Share your thoughts and feelings',
      challenges: 'Challenges',
      challengesDesc: 'Complete tasks to level up',
      streakDays: 'day streak',
      exp: 'EXP'
    },
    rus: {
      goodMorning: 'Доброе утро',
      goodAfternoon: 'Добрый день',
      goodEvening: 'Добрый вечер', 
      todaysGoals: 'Цели на сегодня',
      checkIn: 'Ежедневная проверка',
      checkInDesc: 'Как вы себя чувствуете сегодня?',
      sleepTracker: 'Трекер сна',
      sleepDesc: 'Оптимизируйте циклы отдыха',
      chatWithAvatar: `Чат с ${avatar?.name}`,
      chatDesc: 'Поделитесь своими мыслями и чувствами',
      challenges: 'Вызовы',
      challengesDesc: 'Выполняйте задания для повышения уровня',
      streakDays: 'дней подряд',
      exp: 'ОПЫТ'
    }
  };

  const t = text[language];
  
  const hour = new Date().getHours();
  const greeting = hour < 12 ? t.goodMorning : hour < 17 ? t.goodAfternoon : t.goodEvening;

  const cards = [
    {
      id: 'quiz',
      title: t.checkIn,
      description: t.checkInDesc,
      icon: '📝',
      color: 'from-green-400 to-emerald-500',
      action: () => onViewChange('quiz')
    },
    {
      id: 'chat',
      title: t.chatWithAvatar,
      description: t.chatDesc,
      icon: avatar?.icon || '💬',
      color: avatar?.color || 'from-purple-400 to-blue-500',
      action: () => onViewChange('chat')
    },
    {
      id: 'sleep',
      title: t.sleepTracker,
      description: t.sleepDesc,
      icon: '😴',
      color: 'from-indigo-400 to-purple-500',
      action: () => onViewChange('sleep')
    },
    {
      id: 'challenges',
      title: t.challenges,
      description: t.challengesDesc,
      icon: '🎯',
      color: 'from-orange-400 to-red-500',
      action: () => onViewChange('progress')
    }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {greeting}, {user.name}! 👋
        </h2>
        {avatar && (
          <p className="text-gray-600">
            {language === 'rus' 
              ? `${avatar.name} готов поддержать вас сегодня`
              : `${avatar.name} is ready to support you today`}
          </p>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">🔥</span>
            <span className="text-2xl font-bold text-gray-800">{user.streak}</span>
          </div>
          <p className="text-sm text-gray-600">{t.streakDays}</p>
        </div>
        
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">⭐</span>
            <span className="text-2xl font-bold text-gray-800">{user.experience}</span>
          </div>
          <p className="text-sm text-gray-600">{t.exp}</p>
        </div>
      </div>

      {/* Action Cards */}
      <div className="grid grid-cols-1 gap-4">
        {cards.map((card) => (
          <button
            key={card.id}
            onClick={card.action}
            className="bg-white/60 backdrop-blur-sm rounded-xl p-6 border border-white/20 hover:bg-white/80 transition-all duration-200 text-left group"
          >
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${card.color} flex items-center justify-center text-white text-xl shadow-lg group-hover:scale-110 transition-transform duration-200`}>
                {card.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800 mb-1">{card.title}</h3>
                <p className="text-sm text-gray-600">{card.description}</p>
              </div>
              <div className="text-gray-400 group-hover:text-gray-600 transition-colors">
                →
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}