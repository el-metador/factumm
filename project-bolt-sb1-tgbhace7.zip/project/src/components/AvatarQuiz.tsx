import React, { useState } from 'react';
import { avatarSelectionQuiz } from '../data/quiz';
import { calculateAvatarMatch } from '../utils/avatarAlgorithm';
import { User, Avatar } from '../types';

interface AvatarQuizProps {
  user: User;
  onComplete: (user: User, avatar: Avatar) => void;
}

export function AvatarQuiz({ user, onComplete }: AvatarQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const language = user.settings.language;
  const question = avatarSelectionQuiz[currentQuestion];

  const handleAnswer = (value: string) => {
    const newResponses = { ...responses, [question.id]: value };
    setResponses(newResponses);

    if (currentQuestion < avatarSelectionQuiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Quiz completed, calculate avatar
      setIsLoading(true);
      setTimeout(() => {
        const selectedAvatar = calculateAvatarMatch(newResponses);
        const updatedUser = { ...user, avatar: selectedAvatar };
        onComplete(updatedUser, selectedAvatar);
      }, 1500);
    }
  };

  const text = {
    en: {
      title: 'Personality Assessment',
      subtitle: 'Let\'s find your perfect companion',
      question: 'Question',
      of: 'of',
      analyzing: 'Analyzing your responses...',
      finding: 'Finding your perfect companion'
    },
    rus: {
      title: 'Оценка личности',
      subtitle: 'Давайте найдем вашего идеального компаньона',
      question: 'Вопрос',
      of: 'из',
      analyzing: 'Анализируем ваши ответы...',
      finding: 'Ищем вашего идеального компаньона'
    }
  };

  const t = text[language];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-100 to-teal-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center">
          <div className="animate-spin w-16 h-16 border-4 border-purple-200 border-t-purple-500 rounded-full mx-auto mb-6"></div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">{t.analyzing}</h2>
          <p className="text-gray-600">{t.finding}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-100 to-teal-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600 mb-4">{t.subtitle}</p>
          
          {/* Progress bar */}
          <div className="flex items-center gap-2 mb-4">
            <span className="text-sm text-gray-500">
              {t.question} {currentQuestion + 1} {t.of} {avatarSelectionQuiz.length}
            </span>
            <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-300"
                style={{ width: `${((currentQuestion + 1) / avatarSelectionQuiz.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-6">
            {question.text[language]}
          </h2>
          
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={option.value}
                onClick={() => handleAnswer(option.value)}
                className="w-full p-4 text-left border-2 border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <span className="text-gray-800">{option.text[language]}</span>
              </button>
            ))}
          </div>
        </div>

        {currentQuestion > 0 && (
          <button
            onClick={() => setCurrentQuestion(currentQuestion - 1)}
            className="text-purple-600 hover:text-purple-700 font-medium"
          >
            ← {language === 'rus' ? 'Назад' : 'Back'}
          </button>
        )}
      </div>
    </div>
  );
}