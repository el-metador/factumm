import React from 'react';
import { User } from '../types';
import { calculateLevel } from '../utils/levels';
import { storage } from '../utils/storage';

interface ProgressScreenProps {
  user: User;
}

export function ProgressScreen({ user }: ProgressScreenProps) {
  const language = user.settings.language;
  const { level, title, progress } = calculateLevel(user.experience);
  const quizzes = storage.getDailyQuizzes();

  // Calculate mood trend
  const recentQuizzes = quizzes.slice(-7); // Last 7 days
  const avgMood = recentQuizzes.length > 0 
    ? recentQuizzes.reduce((sum, quiz) => sum + quiz.moodScore, 0) / recentQuizzes.length
    : 0;

  const text = {
    en: {
      title: 'Your Progress',
      currentLevel: 'Current Level',
      experience: 'Experience Points',
      streak: 'Current Streak',
      days: 'days',
      moodTrend: 'Mood Trend (7 days)',
      excellent: 'Excellent',
      good: 'Good',
      okay: 'Okay',
      needsAttention: 'Needs Attention',
      achievements: 'Achievements',
      weeklyGoals: 'Weekly Goals',
      completeDaily: 'Complete daily check-ins',
      chatRegular: 'Chat with your avatar regularly',
      maintainSleep: 'Maintain healthy sleep schedule'
    },
    rus: {
      title: 'Ваш прогресс',
      currentLevel: 'Текущий уровень',
      experience: 'Очки опыта',
      streak: 'Текущая серия',
      days: 'дней',
      moodTrend: 'Тренд настроения (7 дней)',
      excellent: 'Отлично',
      good: 'Хорошо',
      okay: 'Нормально',
      needsAttention: 'Требует внимания',
      achievements: 'Достижения',
      weeklyGoals: 'Недельные цели',
      completeDaily: 'Выполняйте ежедневные проверки',
      chatRegular: 'Регулярно общайтесь с вашим аватаром',
      maintainSleep: 'Поддерживайте здоровый режим сна'
    }
  };

  const t = text[language];

  const getMoodStatus = (score: number) => {
    if (score >= 80) return { text: t.excellent, color: 'text-green-600' };
    if (score >= 60) return { text: t.good, color: 'text-blue-600' };
    if (score >= 40) return { text: t.okay, color: 'text-yellow-600' };
    return { text: t.needsAttention, color: 'text-red-600' };
  };

  const moodStatus = getMoodStatus(avgMood);

  const achievements = [
    { 
      icon: '🌟', 
      title: language === 'rus' ? 'Первый шаг' : 'First Step',
      description: language === 'rus' ? 'Завершили первый опрос' : 'Completed first quiz',
      unlocked: quizzes.length > 0
    },
    {
      icon: '🔥',
      title: language === 'rus' ? 'На пути' : 'On a Roll',
      description: language === 'rus' ? '7-дневная серия' : '7-day streak',
      unlocked: user.streak >= 7
    },
    {
      icon: '💬',
      title: language === 'rus' ? 'Открытое сердце' : 'Open Heart',
      description: language === 'rus' ? 'Поделились с аватаром' : 'Shared with avatar',
      unlocked: storage.getChatMessages().filter(m => m.type === 'user').length > 0
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">{t.title}</h2>
        
        {/* Level Progress */}
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold text-gray-800">{t.currentLevel}</span>
            <span className="text-2xl font-bold text-purple-600">Level {level}</span>
          </div>
          <p className="text-gray-600 mb-3">{title[language]}</p>
          <div className="w-full h-4 bg-white rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-sm text-gray-600 mt-2">{Math.round(progress)}% to next level</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{user.experience}</div>
            <div className="text-sm text-gray-600">{t.experience}</div>
          </div>
          <div className="bg-white rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{user.streak}</div>
            <div className="text-sm text-gray-600">{t.streak} {t.days}</div>
          </div>
        </div>

        {/* Mood Trend */}
        <div className="bg-white rounded-xl p-4 mb-6">
          <h3 className="font-semibold text-gray-800 mb-2">{t.moodTrend}</h3>
          <div className="flex items-center justify-between">
            <div className="text-3xl font-bold text-gray-800">{Math.round(avgMood)}%</div>
            <div className={`font-medium ${moodStatus.color}`}>{moodStatus.text}</div>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden mt-2">
            <div 
              className="h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 transition-all duration-300"
              style={{ width: `${avgMood}%` }}
            />
          </div>
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">{t.achievements}</h3>
        <div className="space-y-3">
          {achievements.map((achievement, index) => (
            <div 
              key={index}
              className={`flex items-center gap-4 p-4 rounded-xl transition-all ${
                achievement.unlocked 
                  ? 'bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200' 
                  : 'bg-gray-50 opacity-60'
              }`}
            >
              <span className="text-2xl">{achievement.icon}</span>
              <div className="flex-1">
                <h4 className="font-medium text-gray-800">{achievement.title}</h4>
                <p className="text-sm text-gray-600">{achievement.description}</p>
              </div>
              {achievement.unlocked && (
                <span className="text-yellow-600 font-semibold text-sm">✓</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Weekly Goals */}
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">{t.weeklyGoals}</h3>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
              quizzes.length >= 3 ? 'bg-green-500 border-green-500' : 'border-gray-300'
            }`}>
              {quizzes.length >= 3 && <span className="text-white text-xs">✓</span>}
            </div>
            <span className="text-gray-700">{t.completeDaily}</span>
          </div>
          <div className="flex items-center gap-3">
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
              storage.getChatMessages().filter(m => m.type === 'user').length >= 5 ? 'bg-green-500 border-green-500' : 'border-gray-300'
            }`}>
              {storage.getChatMessages().filter(m => m.type === 'user').length >= 5 && <span className="text-white text-xs">✓</span>}
            </div>
            <span className="text-gray-700">{t.chatRegular}</span>
          </div>
          <div className="flex items-center gap-3">
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
              storage.getSleepData() ? 'bg-green-500 border-green-500' : 'border-gray-300'
            }`}>
              {storage.getSleepData() && <span className="text-white text-xs">✓</span>}
            </div>
            <span className="text-gray-700">{t.maintainSleep}</span>
          </div>
        </div>
      </div>
    </div>
  );
}