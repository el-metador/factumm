import React, { useState } from 'react';
import { User, UserSettings } from '../types';

interface AuthScreenProps {
  onAuth: (user: User) => void;
  language: 'en' | 'rus';
  onLanguageChange: (lang: 'en' | 'rus') => void;
}

export function AuthScreen({ onAuth, language, onLanguageChange }: AuthScreenProps) {
  const [isSignUp, setIsSignUp] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.email || !formData.password || (isSignUp && !formData.name)) return;

    const user: User = {
      id: Date.now().toString(),
      email: formData.email,
      name: formData.name || formData.email.split('@')[0],
      level: 1,
      experience: 0,
      title: language === 'rus' ? 'Странник в тумане' : 'Fog Wanderer',
      streak: 0,
      completedChallenges: [],
      settings: {
        language,
        theme: 'light',
        notifications: true,
        dataLogging: false
      },
      createdAt: new Date()
    };

    onAuth(user);
  };

  const handleOAuthLogin = (provider: string) => {
    // Simulated OAuth login
    const user: User = {
      id: Date.now().toString(),
      email: `user@${provider}.com`,
      name: `${provider.charAt(0).toUpperCase() + provider.slice(1)} User`,
      level: 1,
      experience: 0,
      title: language === 'rus' ? 'Странник в тумане' : 'Fog Wanderer',
      streak: 0,
      completedChallenges: [],
      settings: {
        language,
        theme: 'light',
        notifications: true,
        dataLogging: false
      },
      createdAt: new Date()
    };

    onAuth(user);
  };

  const text = {
    en: {
      welcome: 'Welcome to Factum',
      subtitle: 'Your personal mental health companion',
      name: 'Full Name',
      email: 'Email',
      password: 'Password',
      signUp: 'Create Account',
      signIn: 'Sign In',
      continueWith: 'Continue with',
      haveAccount: 'Already have an account?',
      noAccount: "Don't have an account?",
      switchToSignIn: 'Sign in here',
      switchToSignUp: 'Sign up here',
      privacy: 'Your data stays private and secure on your device'
    },
    rus: {
      welcome: 'Добро пожаловать в Factum',
      subtitle: 'Ваш персональный помощник для ментального здоровья',
      name: 'Полное имя',
      email: 'Email',
      password: 'Пароль',
      signUp: 'Создать аккаунт',
      signIn: 'Войти',
      continueWith: 'Продолжить с',
      haveAccount: 'Уже есть аккаунт?',
      noAccount: 'Нет аккаунта?',
      switchToSignIn: 'Войти здесь',
      switchToSignUp: 'Зарегистрироваться здесь',
      privacy: 'Ваши данные остаются приватными и безопасными на вашем устройстве'
    }
  };

  const t = text[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-100 to-teal-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Language Toggle */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg p-1 shadow-sm">
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                language === 'en' 
                  ? 'bg-purple-100 text-purple-700' 
                  : 'text-gray-600 hover:text-purple-600'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => onLanguageChange('rus')}
              className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                language === 'rus' 
                  ? 'bg-purple-100 text-purple-700' 
                  : 'text-gray-600 hover:text-purple-600'
              }`}
            >
              RUS
            </button>
          </div>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-2xl text-white font-bold mx-auto mb-4">
              F
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">{t.welcome}</h1>
            <p className="text-gray-600">{t.subtitle}</p>
          </div>

          {/* OAuth Buttons */}
          <div className="space-y-3 mb-6">
            <button
              onClick={() => handleOAuthLogin('google')}
              className="w-full bg-red-50 border border-red-100 rounded-lg py-3 px-4 flex items-center justify-center gap-3 text-red-700 font-medium hover:bg-red-100 transition-colors"
            >
              <span>🔍</span>
              {t.continueWith} Google
            </button>
            <button
              onClick={() => handleOAuthLogin('github')}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg py-3 px-4 flex items-center justify-center gap-3 text-gray-700 font-medium hover:bg-gray-100 transition-colors"
            >
              <span>📱</span>
              {t.continueWith} GitHub
            </button>
          </div>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">or</span>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div>
                <input
                  type="text"
                  placeholder={t.name}
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                  required={isSignUp}
                />
              </div>
            )}
            <div>
              <input
                type="email"
                placeholder={t.email}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                required
              />
            </div>
            <div>
              <input
                type="password"
                placeholder={t.password}
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-blue-500 text-white font-semibold py-3 rounded-lg hover:from-purple-600 hover:to-blue-600 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              {isSignUp ? t.signUp : t.signIn}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              {isSignUp ? t.haveAccount : t.noAccount}{' '}
              <button
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-purple-600 font-medium hover:text-purple-700"
              >
                {isSignUp ? t.switchToSignIn : t.switchToSignUp}
              </button>
            </p>
          </div>

          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">{t.privacy}</p>
          </div>
        </div>
      </div>
    </div>
  );
}