import React, { useState } from 'react';
import { Avatar, User } from '../types';

interface AvatarRevealProps {
  user: User;
  avatar: Avatar;
  onContinue: () => void;
}

export function AvatarReveal({ user, avatar, onContinue }: AvatarRevealProps) {
  const [isRevealed, setIsRevealed] = useState(false);
  const language = user.settings.language;

  React.useEffect(() => {
    const timer = setTimeout(() => setIsRevealed(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const text = {
    en: {
      meet: 'Meet your companion',
      companion: 'Your Companion',
      traits: 'Specialized in helping with',
      continue: 'Continue to Chat',
      description: `${avatar.name} understands your unique journey and is here to provide personalized support. Together, you'll work on building healthier patterns and finding your inner strength.`
    },
    rus: {
      meet: 'Познакомьтесь с вашим компаньоном',
      companion: 'Ваш компаньон',
      traits: 'Специализируется на помощи с',
      continue: 'Перейти к чату',
      description: `${avatar.name} понимает ваш уникальный путь и здесь, чтобы обеспечить персональную поддержку. Вместе вы будете работать над построением более здоровых паттернов и поиском внутренней силы.`
    }
  };

  const t = text[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-100 to-teal-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-8">{t.meet}</h1>
        
        <div className={`transition-all duration-1000 ${isRevealed ? 'scale-100 opacity-100' : 'scale-50 opacity-0'}`}>
          <div className={`w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-r ${avatar.color} flex items-center justify-center shadow-lg`}>
            <span className="text-6xl">{avatar.icon}</span>
          </div>
          
          <h2 className="text-3xl font-bold text-gray-800 mb-2">{avatar.name}</h2>
          <p className="text-lg text-gray-600 mb-6">{t.companion}</p>
          
          <div className="bg-gray-50 rounded-xl p-6 mb-6 text-left">
            <p className="text-gray-700 mb-4">{t.description}</p>
            
            <div className="mb-4">
              <h3 className="font-semibold text-gray-800 mb-2">{t.traits}:</h3>
              <div className="flex flex-wrap gap-2">
                {avatar.traits.map((trait, index) => (
                  <span 
                    key={index}
                    className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm"
                  >
                    {trait}
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          <button
            onClick={onContinue}
            className={`w-full bg-gradient-to-r ${avatar.color} text-white font-semibold py-4 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105`}
          >
            {t.continue}
          </button>
        </div>
      </div>
    </div>
  );
}