import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage } from '../types';
import { generateAvatarResponse } from '../utils/avatarAlgorithm';
import { storage } from '../utils/storage';

interface ChatScreenProps {
  user: User;
}

export function ChatScreen({ user }: ChatScreenProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const language = user.settings.language;
  const avatar = user.avatar;

  useEffect(() => {
    // Load existing messages
    const savedMessages = storage.getChatMessages();
    setMessages(savedMessages);

    // Add welcome message if no messages exist
    if (savedMessages.length === 0 && avatar) {
      const welcomeMessage: ChatMessage = {
        id: Date.now().toString(),
        type: 'avatar',
        content: language === 'rus' 
          ? `Привет! Я ${avatar.name}. Я здесь, чтобы выслушать и поддержать тебя. Как дела?`
          : `Hello! I'm ${avatar.name}. I'm here to listen and support you. How are you doing?`,
        timestamp: new Date(),
        avatarType: avatar.type
      };
      setMessages([welcomeMessage]);
      storage.addChatMessage(welcomeMessage);
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const sendMessage = async () => {
    if (!inputValue.trim() || !avatar) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    storage.addChatMessage(userMessage);
    setInputValue('');
    setIsTyping(true);

    // Simulate avatar thinking time
    setTimeout(() => {
      const avatarResponse = generateAvatarResponse(avatar.type, userMessage.content, language);
      const avatarMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'avatar',
        content: avatarResponse,
        timestamp: new Date(),
        avatarType: avatar.type
      };

      setMessages(prev => [...prev, avatarMessage]);
      storage.addChatMessage(avatarMessage);
      setIsTyping(false);
    }, 1500 + Math.random() * 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const text = {
    en: {
      placeholder: 'Share your thoughts...',
      send: 'Send',
      typing: `${avatar?.name} is typing...`
    },
    rus: {
      placeholder: 'Поделитесь своими мыслями...',
      send: 'Отправить',
      typing: `${avatar?.name} печатает...`
    }
  };

  const t = text[language];

  return (
    <div className="flex flex-col h-[calc(100vh-180px)]">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              message.type === 'user'
                ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white'
                : 'bg-white/80 backdrop-blur-sm border border-white/20 text-gray-800'
            }`}>
              {message.type === 'avatar' && avatar && (
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{avatar.icon}</span>
                  <span className="font-medium text-sm">{avatar.name}</span>
                </div>
              )}
              <p className="text-sm leading-relaxed">{message.content}</p>
              <p className={`text-xs mt-2 ${
                message.type === 'user' ? 'text-purple-100' : 'text-gray-500'
              }`}>
                {new Date(message.timestamp).toLocaleTimeString(language === 'rus' ? 'ru-RU' : 'en-US', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white/80 backdrop-blur-sm border border-white/20 rounded-2xl px-4 py-3 max-w-[80%]">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg">{avatar?.icon}</span>
                <span className="font-medium text-sm">{avatar?.name}</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl border border-white/20 p-4">
        <div className="flex gap-3">
          <textarea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={t.placeholder}
            className="flex-1 resize-none bg-transparent outline-none text-gray-800 placeholder-gray-500 min-h-[20px] max-h-20"
            rows={1}
          />
          <button
            onClick={sendMessage}
            disabled={!inputValue.trim()}
            className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
              inputValue.trim()
                ? `bg-gradient-to-r ${avatar?.color} text-white hover:scale-105 shadow-lg`
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            {t.send}
          </button>
        </div>
      </div>
    </div>
  );
}