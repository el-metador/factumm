import React from 'react';
import { User } from '../types';
import { calculateLevel } from '../utils/levels';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  currentView: string;
  onViewChange: (view: string) => void;
}

export function Layout({ children, user, currentView, onViewChange }: LayoutProps) {
  if (!user) {
    return <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">{children}</div>;
  }

  const { level, title, progress } = calculateLevel(user.experience);
  const language = user.settings.language;

  const navigation = [
    { id: 'dashboard', icon: '🏠', label: { en: 'Home', rus: 'Главная' } },
    { id: 'chat', icon: user.avatar?.icon || '💬', label: { en: 'Chat', rus: 'Чат' } },
    { id: 'sleep', icon: '😴', label: { en: 'Sleep', rus: 'Сон' } },
    { id: 'progress', icon: '📊', label: { en: 'Progress', rus: 'Прогресс' } },
    { id: 'settings', icon: '⚙️', label: { en: 'Settings', rus: 'Настройки' } }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-purple-100 px-4 py-3">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${user.avatar?.color} flex items-center justify-center text-white font-semibold`}>
              {user.avatar?.icon}
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-800">
                {language === 'rus' ? `Привет, ${user.name}` : `Hello, ${user.name}`}
              </h1>
              <p className="text-sm text-gray-600">{title[language]}</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm font-medium text-purple-600">Level {level}</div>
            <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 py-6 pb-20">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-purple-100">
        <div className="max-w-md mx-auto flex">
          {navigation.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`flex-1 py-3 px-2 flex flex-col items-center gap-1 transition-colors duration-200 ${
                currentView === item.id 
                  ? 'text-purple-600' 
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="text-xs font-medium">{item.label[language]}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}