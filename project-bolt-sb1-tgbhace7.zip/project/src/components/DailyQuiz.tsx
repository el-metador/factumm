import React, { useState } from 'react';
import { User, DailyQuiz } from '../types';
import { dailyQuizQuestions } from '../data/quiz';
import { storage } from '../utils/storage';

interface DailyQuizProps {
  user: User;
  onComplete: (user: User) => void;
}

export function DailyQuiz({ user, onComplete }: DailyQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<Record<string, string>>({});
  const language = user.settings.language;

  const today = new Date().toISOString().split('T')[0];
  const existingQuiz = storage.getDailyQuizzes().find(q => q.date === today);

  if (existingQuiz) {
    return (
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <div className="text-center">
          <span className="text-4xl mb-4 block">✅</span>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">
            {language === 'rus' ? 'Отличная работа!' : 'Great job!'}
          </h2>
          <p className="text-gray-600">
            {language === 'rus' 
              ? 'Вы уже прошли сегодняшний опрос!' 
              : "You've already completed today's check-in!"}
          </p>
        </div>
      </div>
    );
  }

  const question = dailyQuizQuestions[currentQuestion];

  const handleAnswer = (value: string) => {
    const newResponses = { ...responses, [question.id]: value };
    setResponses(newResponses);

    if (currentQuestion < dailyQuizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Quiz completed
      const moodScore = calculateMoodScore(newResponses);
      const quiz: DailyQuiz = {
        id: Date.now().toString(),
        date: today,
        questions: dailyQuizQuestions,
        responses: newResponses,
        moodScore
      };

      storage.addDailyQuiz(quiz);
      
      // Update user experience
      const updatedUser = {
        ...user,
        experience: user.experience + 25,
        streak: user.streak + 1
      };
      
      storage.setUser(updatedUser);
      onComplete(updatedUser);
    }
  };

  const calculateMoodScore = (responses: Record<string, string>): number => {
    let score = 0;
    Object.values(responses).forEach(response => {
      switch (response) {
        case 'great':
        case 'excellent':
          score += 5;
          break;
        case 'good':
          score += 4;
          break;
        case 'okay':
          score += 3;
          break;
        case 'struggling':
        case 'restless':
          score += 2;
          break;
        case 'difficult':
        case 'poor':
          score += 1;
          break;
      }
    });
    return Math.round((score / (Object.keys(responses).length * 5)) * 100);
  };

  const text = {
    en: {
      title: 'Daily Check-in',
      subtitle: 'How are you feeling today?',
      question: 'Question',
      of: 'of'
    },
    rus: {
      title: 'Ежедневная проверка',
      subtitle: 'Как вы себя чувствуете сегодня?',
      question: 'Вопрос',
      of: 'из'
    }
  };

  const t = text[language];

  return (
    <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{t.title}</h2>
        <p className="text-gray-600 mb-4">{t.subtitle}</p>
        
        <div className="flex items-center gap-2 mb-4">
          <span className="text-sm text-gray-500">
            {t.question} {currentQuestion + 1} {t.of} {dailyQuizQuestions.length}
          </span>
          <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / dailyQuizQuestions.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          {question.text[language]}
        </h3>
        
        <div className="space-y-3">
          {question.options.map((option) => (
            <button
              key={option.value}
              onClick={() => handleAnswer(option.value)}
              className="w-full p-4 text-left border-2 border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <span className="text-gray-800">{option.text[language]}</span>
            </button>
          ))}
        </div>
      </div>

      {currentQuestion > 0 && (
        <button
          onClick={() => setCurrentQuestion(currentQuestion - 1)}
          className="text-green-600 hover:text-green-700 font-medium"
        >
          ← {language === 'rus' ? 'Назад' : 'Back'}
        </button>
      )}
    </div>
  );
}